package com.practice.problem;

public class StringDemo {

		public static void main(String[] args) {
			
		
		String str= "JAVA is Simple";
		
		System.out.println(str.toUpperCase()); //printing string into UpperCase
		
		System.out.println(str.toLowerCase()); //printing string into LowerCase
		
		
		String[] words=str.split("\\s");	//1st words of letter
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
		
		String[] words1=str.split("\\s"); // Change order 
		for(String w:words1){  
			System.out.println(w); 
		}
		
		//String Builder reverse
		StringBuilder words2= new StringBuilder("JAVA is Simple");
		
		System.out.println("String = " + words2.toString());
		StringBuilder reverseStr = words2.reverse();
		System.out.println("Reverse String = " + reverseStr.toString());
		
		//Total Length
		System.out.println("length of string " + str.length());
	}
	}