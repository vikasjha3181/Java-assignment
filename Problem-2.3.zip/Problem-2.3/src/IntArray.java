
public class IntArray {
	public static void main(String[] args) {  
          
        int [] arr = new int [] {1, 2, 3, 4, 5,6,7,8,9,10,11,12,13};  
        int sum = 0;  
        for (int i = 0; i < arr.length; i++) {  
           sum = sum + arr[i];  
        }  
        double avg = sum/arr.length;
        System.out.println("Sum of all the elements of an array: " + sum);
        System.out.println("Avrage of all the number is:" +avg);

    }  

}
