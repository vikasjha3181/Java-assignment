import java.util.Scanner;

class ShuffleStringDemo
{
	
	public static boolean isInterleaving(String a, String b, String c)
	{
		
		if (a.length() == 0 && b.length() == 0 && c.length() == 0) {
			return true;
		}

		if (c.length() == 0) {
			return false;
		}


		boolean x = (a.length() != 0 && c.charAt(0) == a.charAt(0)) &&
				isInterleaving(a.substring(1), b, c.substring(1));


		boolean y = (b.length() != 0 && c.charAt(0) == b.charAt(0)) &&
				isInterleaving(a, b.substring(1), c.substring(1));

		return x || y;
	}

	public static void main(String[] args)
	{
		
		
		Scanner S=new Scanner(System.in);
		System.out.println("Enter First String :");
		String a=S.nextLine();
		System.out.println("Enter Second String :");
		String b=S.nextLine();
		System.out.println("Enter Third String :");
		String c=S.nextLine();		
		

		if (isInterleaving(a, b, c)) {
			System.out.print("Interleaving");
		}
		else {
			System.out.print("Given string is not interleaving of a and b");
		}
	}
}