package com.practice.problem;

public abstract class Instrument {
	public abstract void play();
}
