
public class TestRectangle {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(5,5);
		r1.areaRectangle();
		r1.perimeterRectangle();
		r1.display();
		
		Rectangle r2 = new Rectangle(15,13);
		r2.areaRectangle();
		r2.perimeterRectangle();
		r2.display();
		
		Rectangle r3 = new Rectangle(7,5);
		r3.areaRectangle();
		r3.perimeterRectangle();
		r3.display();
		
		Rectangle r4 = new Rectangle(9,7);
		r4.areaRectangle();
		r4.perimeterRectangle();
		r4.display();
		
		Rectangle r5 = new Rectangle(23,20);
		r5.areaRectangle();
		r5.perimeterRectangle();
		r5.display();

	}

}
