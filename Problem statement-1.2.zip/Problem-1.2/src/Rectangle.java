import java.util.Scanner;

public class Rectangle {
	
	int length; 
	int width; 
	int area; 
	int parameter;
	public Rectangle(int length, int width) {
		this.length = length;
		this.width = width;
		
	}
	
	 void  areaRectangle()
	    {
	        area = length * width;
	       
	    }
	 
	     void  perimeterRectangle()
	    {
	    	 parameter = 2*(length + width);
	       
	    }

	    void display() {
	    	if(length>0 && length<20) {
	        
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Parameter of Rectangle = " +parameter);
	        System.out.println("****************************************");
	    	}
	       
	        }
	
	    
	   

}
